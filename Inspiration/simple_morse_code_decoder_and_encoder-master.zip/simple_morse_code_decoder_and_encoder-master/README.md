# simple_morse_code_decoder_and_encoder
Simple Text based morse encoder and decoder.

morse json creator: https://gist.github.com/mohayonao/094c71af14fe4791c5dd
